streams = [
        [1,1,2,2,2,2,2],
        [1,1,2,3,3,3,2],
        [1,4,1,3,3,5,5],
        [4,4,3,1,3,5,5],
        [4,6,6,6,7,7,5],
        [6,4,6,4,5,5,7],
        [6,6,4,7,7,7,7]
       ]

placed = [
    [2,1,1],
    [2,3,7],
    [2,5,6],
    [2,7,4],
    [3,2,7],
    [3,6,1],
    [4,1,4],
    [4,7,5],
    [5,2,2],
    [5,6,6]
    ]

# From Strimko Monthly #02
# See http://www.hakank.org/google_or_tools/strimko2.py
#
# Copyright 2010 Hakan Kjellerstrand hakank@bonetmail.com
#
# Licensed under the Apache License, Version 2.0 (the 'License'); 
# you may not use this file except in compliance with the License. 
# You may obtain a copy of the License at 
#
#     http://www.apache.org/licenses/LICENSE-2.0 
#
# Unless required by applicable law or agreed to in writing, software 
# distributed under the License is distributed on an 'AS IS' BASIS, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
# See the License for the specific language governing permissions and 
# limitations under the License. 
